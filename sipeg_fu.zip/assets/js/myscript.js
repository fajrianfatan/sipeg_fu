const flashData = $('.flash-data').data('flashdata');
console.log(flashData);